<?php
// Verifica se o formulário foi enviado via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Conexão com o banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "task_management_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verifica se há erro na conexão
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    // Obtém os dados do POST
    $numero_os = $_POST['numero_os'];
    $descricao_problema = $_POST['descricao_problema'];
    $condicao = $_POST['condicao']; // Alterado de "status" para "condicao"
    $id = $_POST['id']; // ID da ordem de serviço

    // Consulta para atualizar os dados no banco
    $sql = "UPDATE ordens_servico SET numero_os = ?, descricao = ?, condicao = ? WHERE id = ?";

    // Prepara a consulta
    if ($stmt = $conn->prepare($sql)) {
        // Associa os parâmetros
        $stmt->bind_param("sssi", $numero_os, $descricao_problema, $condicao, $id);
        
        // Executa a consulta
        if ($stmt->execute()) {
            // Se a atualização for bem-sucedida
            echo json_encode(['status' => 'success', 'message' => 'Status atualizado com sucesso.']);
        } else {
            // Se ocorrer um erro na execução
            echo json_encode(['status' => 'error', 'message' => 'Erro ao atualizar o status.']);
        }

        // Fecha a declaração
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Erro ao preparar a consulta.']);
    }

    // Fecha a conexão
    $conn->close();
}
?>
