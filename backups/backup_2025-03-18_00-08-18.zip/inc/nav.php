<nav class="side-bar">
			<div class="user-p">
				<img src="img/user.png">
				<h4>@<?=$_SESSION['username']?></h4>
			</div>
			
			<?php 

               if($_SESSION['role'] == "employee"){
			 ?>
			 <!-- Employee Navigation Bar -->
			<ul id="navList">
				<li>
					<a href="index.php">
						<i class="fa fa-tachometer" aria-hidden="true"></i>
						<span>Painel</span>
					</a>
				</li>
				<li>
					<a href="my_task.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Novo Equipamento</span>
					</a>
				</li>
				<li>
					<a href="consulta.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Consultas</span>
					</a>
				</li>
				<li>
					<a href="cadastro_anydesk.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Anydesk</span>
					</a>
				</li>
				<li>
					<a href="backup.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Backup</span>
					</a>
				</li>
				<li>
					<a href="my_task.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Ordem de Serviço</span>
					</a>
				</li>
				<li>
					<a href="my_task.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Chamados</span>
					</a>
				</li>			
				<li>
					<a href="my_task.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Entradas e Saídas</span>
					</a>
				</li>
				<li>
					<a href="User.php">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Perfil</span>
					</a>
				</li>
				<li>
					<a href="logs.php">
						<i class="fa fa-bell" aria-hidden="true"></i>
						<span>Logs</span>
					</a>
				</li>
				<li>
					<a href="notifications.php">
						<i class="fa fa-bell" aria-hidden="true"></i>
						<span>Notificações</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Saída</span>
					</a>
				</li>
			</ul>
		<?php }else { ?>
			<!-- Admin Navigation Bar -->
            <ul id="navList">
				<li>
					<a href="index.php">
						<i class="fa fa-tachometer" aria-hidden="true"></i>
						<span>Painel</span>
					</a>
				</li>
				<li>
					<a href="user.php">
						<i class="fa fa-users" aria-hidden="true"></i>
						<span>Usuários</span>
					</a>
				</li>
				<li>
					<a href="create_task.php">
						<i class="fa fa-plus" aria-hidden="true"></i>
						<span>Abrir Chamado</span>
					</a>
				</li>
				<li>
					<a href="tasks.php">
						<i class="fa fa-tasks" aria-hidden="true"></i>
						<span>Todos os chamados</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-sign-out" aria-hidden="true"></i>
						<span>Saída</span>
					</a>
				</li>
			</ul>
		<?php } ?>
		</nav>