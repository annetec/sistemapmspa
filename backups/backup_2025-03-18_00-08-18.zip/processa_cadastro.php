<?php
session_start();
include "DB_connection.php";

if (!isset($_SESSION['role']) || !isset($_SESSION['id'])) {
    header("Location: login.php?error=First login");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturando os dados do formulário com trim() para remover espaços em branco extras
    $equipamento = trim($_POST['equipamento'] ?? '');
    $categoria = trim($_POST['categoria'] ?? '');
    $numero_serie = trim($_POST['numero_serie'] ?? 'N/A');  // Se vazio, define como 'N/A'
    $secretaria = trim($_POST['secretaria'] ?? '');
    $setor = trim($_POST['setor'] ?? '');
    $responsavel = trim($_POST['responsavel'] ?? '');
    $nome_computador = trim($_POST['nome_computador'] ?? null);
    $ip = trim($_POST['ip'] ?? null);
    $observacao = trim($_POST['observacao'] ?? null);

    // Se for roteador, captura os dados adicionais
    $ssid = $senha = $ip_wan = $usuario_admin = $senha_admin = null;
    if ($categoria === "Roteador") {
        $ssid = trim($_POST['ssid'] ?? null);
        $senha = trim($_POST['senha'] ?? null);
        $ip_wan = trim($_POST['ip_wan'] ?? null);
        $usuario_admin = trim($_POST['usuario_admin'] ?? null);
        $senha_admin = trim($_POST['senha_admin'] ?? null);
    }

    // Capturando o ID do usuário logado
    $usuario_id = $_SESSION['id'];

    try {
        // Preparação da query com PDO
        $sql = "INSERT INTO chamados 
                (equipamento, categoria, numero_serie, secretaria, setor, responsavel, 
                 nome_computador, ip, observacao, ssid, senha, ip_wan, usuario_admin, 
                 senha_admin, usuario_id, data_cadastro) 
                VALUES (:equipamento, :categoria, :numero_serie, :secretaria, :setor, :responsavel, 
                        :nome_computador, :ip, :observacao, :ssid, :senha, :ip_wan, 
                        :usuario_admin, :senha_admin, :usuario_id, NOW())";

        $stmt = $conn->prepare($sql);

        // Bind dos parâmetros
        $stmt->bindParam(":equipamento", $equipamento);
        $stmt->bindParam(":categoria", $categoria);
        $stmt->bindParam(":numero_serie", $numero_serie);
        $stmt->bindParam(":secretaria", $secretaria);
        $stmt->bindParam(":setor", $setor);
        $stmt->bindParam(":responsavel", $responsavel);
        $stmt->bindParam(":nome_computador", $nome_computador);
        $stmt->bindParam(":ip", $ip);
        $stmt->bindParam(":observacao", $observacao);
        $stmt->bindParam(":ssid", $ssid);
        $stmt->bindParam(":senha", $senha);
        $stmt->bindParam(":ip_wan", $ip_wan);
        $stmt->bindParam(":usuario_admin", $usuario_admin);
        $stmt->bindParam(":senha_admin", $senha_admin);
        $stmt->bindParam(":usuario_id", $usuario_id, PDO::PARAM_INT);

        // Executa a query
        $stmt->execute();

        // Redireciona após sucesso
        header("Location: index.php?success=Cadastro realizado com sucesso");
        exit();
    } catch (PDOException $e) {
        die("Erro ao cadastrar: " . $e->getMessage());
    }
}
?>
