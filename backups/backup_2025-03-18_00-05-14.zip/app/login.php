<?php
// Habilitar a exibição de erros para depuração
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Iniciar sessão
session_start();

// Incluir a conexão com o banco
include "../DB_connection.php";

// Verificar se os campos de login foram preenchidos
if (isset($_POST['user_name']) && isset($_POST['password'])) {
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    // Alterar 'user_name' para o nome correto da coluna, por exemplo, 'username'
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bindParam(1, $user_name);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        // Usuário encontrado
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar se a senha está correta
        if (password_verify($password, $user['password'])) {
            // Login bem-sucedido, armazenar os dados na sessão
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['username'];

            // Redirecionar para a página principal
            header("Location: ../index.php");
            exit();
        } else {
            // Senha incorreta
            header("Location: ../login.php?error=Senha incorreta");
            exit();
        }
    } else {
        // Usuário não encontrado
        header("Location: ../login.php?error=Usuário não encontrado");
        exit();
    }
} else {
    // Se os campos não foram preenchidos
    header("Location: ../login.php?error=Preencha todos os campos");
    exit();
}
?>
