<?php 
session_start();
if (isset($_SESSION['user_name']) && isset($_SESSION['user_id'])) {

	include "DB_connection.php";
    include "app/Model/Task.php";
    include "app/Model/User.php";

    // Obtendo o número total de usuários
    $num_users = count_users($conn);

    // Obtendo a contagem de equipamentos por categoria
    function count_equipments_by_category($conn) {
        $query = "SELECT categoria, COUNT(*) as total FROM chamados GROUP BY categoria";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    $equipments_by_category = count_equipments_by_category($conn);

    // Preparando arrays para o gráfico
    $categories = [];
    $category_counts = [];
    foreach ($equipments_by_category as $row) {
        $categories[] = $row['categoria'];
        $category_counts[] = $row['total'];
    }
    
    // Convertendo os arrays para JSON
    $categories_json = json_encode($categories);
    $category_counts_json = json_encode($category_counts);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Painel do Sistema</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<style>
		.dashboard-container {
    		text-align: center;
    		display: flex;
   		 	flex-direction: column;
    		align-items: center;
		}
		.dashboard {
   			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 20px;
			max-width: 800px;
			margin-top: 10px;
		}
		.dashboard-item {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			width: 180px;
			height: 120px;
			border-radius: 10px;
			color: white;
			font-size: 16px;
			font-weight: bold;
			box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.2);
		}
		.dashboard-item i {
			font-size: 24px;
			margin-bottom: 8px;
		}
		.footer {
			position: fixed;
			bottom: 10px;
			left: 0;
			width: 100%;
			text-align: center;
			font-size: 14px;
			color: gray;
		}
		.datetime {
			position: fixed;
			bottom: 10px;
			right: 20px;
			font-size: 14px;
			color: gray;
		}
		.title {
			text-align: center;
			margin-bottom: 20px;
		}
	</style>
</head>
<body>
	<input type="checkbox" id="checkbox">
	<?php include "inc/header.php" ?>
	<div class="body">
		<?php include "inc/nav.php" ?>
		<section class="section-1">
			<div class="dashboard-container">
				<h2 class="title">Painel do Sistema</h2>
				<div class="dashboard">
					<div class="dashboard-item" style="background-color: #3498db;">
						<i class="fa fa-users"></i>
						<span><?=$num_users?> Usuários</span>
					</div>
					<div class="dashboard-item" style="background-color: #e74c3c;">
						<i class="fa fa-cogs"></i>
						<span>Configurações</span>
					</div>
					<div class="dashboard-item" style="background-color: #2ecc71;">
						<i class="fa fa-database"></i>
						<span>Banco de Dados</span>
					</div>
					<div class="dashboard-item" style="background-color: #f1c40f;">
						<i class="fa fa-file"></i>
						<span>Relatórios</span>
					</div>
				</div>
			</div>
			<div class="chart-container" style="width: 50%; margin: auto;">
				<canvas id="equipmentsChart"></canvas>
			</div>
		</section>
		<div class="footer">Direitos Reservados - T.I - PMSPA 2025</div>
		<div class="datetime">
			<span id="currentDate"></span> - <span id="currentTime"></span>
		</div>
	</div>

<script>
	document.getElementById("currentDate").innerText = new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

	function updateClock() {
		document.getElementById("currentTime").innerText = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
	}
	setInterval(updateClock, 1000);
	updateClock();

	const ctx = document.getElementById('equipmentsChart').getContext('2d');
	const categories = <?=$categories_json?>;
	const categoryCounts = <?=$category_counts_json?>;

	const equipmentsChart = new Chart(ctx, {
		type: 'bar',
		data: {
			labels: categories,
			datasets: [{
				label: 'Quantidade por Categoria',
				data: categoryCounts,
				backgroundColor: categories.map(() => '#' + Math.floor(Math.random() * 16777215).toString(16)) // Gera cores aleatórias
			}]
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			scales: {
				y: {
					beginAtZero: true
				}
			}
		}
	});
</script>
</body>
</html>
<?php } else { 
   header("Location: login.php?error=Faça login primeiro");
   exit();
} ?>
