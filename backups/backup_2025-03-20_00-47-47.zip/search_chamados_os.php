<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "task_management_db"; // Nome correto do banco de dados

// Criando a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Pegando o valor da pesquisa do parâmetro GET
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Pegando o valor da página e do limite
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;  // Página atual
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 5;  // Número de itens por página
$offset = ($page - 1) * $limit;  // Cálculo do offset para a consulta SQL

// Consulta para contar o número total de registros com base na pesquisa
$countQuery = "SELECT COUNT(*) AS total FROM ordens_servico 
               WHERE numero_serie LIKE '%$search%' 
               OR categoria LIKE '%$search%' 
               OR equipamento LIKE '%$search%' 
               OR secretaria LIKE '%$search%' 
               OR setor LIKE '%$search%' 
               OR responsavel LIKE '%$search%'";

$countResult = $conn->query($countQuery);
$countRow = $countResult->fetch_assoc();
$totalItems = $countRow['total'];  // Total de registros encontrados

// Consulta para buscar as ordens de serviço (OS) com base no valor de pesquisa e paginação
$sql = "SELECT numero_os, solicitante, prioridade, status, descricao, data_criacao, categoria, equipamento, secretaria, setor, responsavel, numero_serie 
        FROM ordens_servico 
        WHERE numero_serie LIKE '%$search%' 
        OR categoria LIKE '%$search%' 
        OR equipamento LIKE '%$search%' 
        OR secretaria LIKE '%$search%' 
        OR setor LIKE '%$search%' 
        OR responsavel LIKE '%$search%' 
        LIMIT $limit OFFSET $offset";

// Executando a consulta
$result = $conn->query($sql);

// Array para armazenar os dados
$data = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [
            'numero_os' => $row['numero_os'],
            'solicitante' => $row['solicitante'],
            'prioridade' => $row['prioridade'],
            'status' => $row['status'],
            'descricao' => $row['descricao'],
            'data_criacao' => $row['data_criacao'],
            'categoria' => $row['categoria'],
            'equipamento' => $row['equipamento'],
            'secretaria' => $row['secretaria'],
            'setor' => $row['setor'],
            'responsavel' => $row['responsavel'],
            'numero_serie' => $row['numero_serie'],
        ];
    }
}

// Calculando o número total de páginas
$totalPages = ceil($totalItems / $limit);

// Retornando os resultados como JSON
echo json_encode([
    'data' => $data,
    'totalItems' => $totalItems,
    'totalPages' => $totalPages,
]);

// Fechar a conexão
$conn->close();
?>
