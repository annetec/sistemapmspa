<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Ordem de Serviço</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 70%;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .title {
            text-align: center;
            font-size: 26px;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 20px;
        }
        .search-container {
            display: flex;
            justify-content: center;
            margin-bottom: 15px;
        }
        .search-input {
            width: 250px;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.3s;
        }
        .search-input:focus {
            border-color: #007bff;
        }
        .filters-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .filter-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 0 10px;
        }
        .filter-button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
        }
        td {
            background-color: #f9f9f9;
        }
        tr:nth-child(even) td {
            background-color: #f1f1f1;
        }
        tr:hover td {
            background-color: #e9ecef;
        }
        .footer {
            position: fixed;
            bottom: 10px;
            left: 0;
            width: 100%;
            text-align: center;
            font-size: 14px;
            color: #6c757d;
        }
        .datetime {
            position: fixed;
            bottom: 10px;
            right: 20px;
            font-size: 14px;
            color: #6c757d;
        }
        .form-container {
            margin-top: 30px;
        }
        .form-container input, .form-container select, .form-container textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-container textarea {
            height: 150px;
        }
        .form-container button {
            padding: 12px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <input type="checkbox" id="checkbox">
    <?php include "inc/header.php"; ?>
    <div class="body">
        <?php include "inc/nav.php"; ?>
        <section class="section-1">
            <div class="container">
                <h4 class="title">Consulta de Ordens de Serviço</h4>

                <!-- Botões de filtro -->
                <div class="filters-container">
                    <button class="filter-button" onclick="filterOS('em_andamento')">Em Andamento</button>
                    <button class="filter-button" onclick="filterOS('finalizada')">Finalizadas</button>
                </div>

                <!-- Campo de pesquisa -->
                <div class="search-container">
                    <input type="text" id="searchNumeroSerie" class="search-input" placeholder="Buscar por Nº de Série" onkeyup="searchData()">
                </div>

                <!-- Tabela de resultados -->
                <table>
                    <thead>
                        <tr>
                            <th>Categoria</th>
                            <th>Equipamento</th>
                            <th>Secretaria</th>
                            <th>Setor</th>
                            <th>Responsável</th>
                            <th>Número de Série</th>
                        </tr>
                    </thead>
                    <tbody id="resultsTable">
                        <!-- Os resultados da pesquisa serão inseridos aqui via AJAX -->
                    </tbody>
                </table>

                <div class="form-container">
                    <h5>Detalhes da Ordem de Serviço</h5>

                    <label for="numeroOS">Número da OS</label>
                    <input type="text" id="numeroOS" readonly>

                    <label for="dataAbertura">Data de Abertura</label>
                    <input type="text" id="dataAbertura" readonly>

                    <label for="prioridade">Prioridade</label>
                    <select id="prioridade">
                        <option value="baixa">Baixa</option>
                        <option value="media">Média</option>
                        <option value="alta">Alta</option>
                    </select>

                    <label for="solicitante">Solicitante</label>
                    <input type="text" id="solicitante">

                    <label for="status">Status</label>
                    <select id="status">
                        <option value="aberta">Aberta</option>
                        <option value="em_andamento">Em Andamento</option>
                        <option value="aguardando_aprovacao">Aguardando Aprovação</option>
                        <option value="pendente">Pendente</option>
                        <option value="troca_comercial">Troca Comercial</option>
                        <option value="substituicao_equipamento">Substituição de Equipamento</option>
                        <option value="aguardando_pecas">Aguardando Peças</option>
                        <option value="revisao">Revisão</option>
                    </select>

                    <label for="descricao">Descrição do Problema/Serviço</label>
                    <textarea id="descricao"></textarea>

                    <button type="button" onclick="saveOS()">Salvar Alterações</button>
                </div>

            </div>
        </section>
    </div>

    <div class="footer">
        <p>Direitos Reservados - T.I - PMSPA 2025</p>
    </div>
    <div class="datetime">
        <p><?= date('d/m/Y H:i:s'); ?></p>
    </div>

    <script>
        let currentPage = 1;
        const itemsPerPage = 5;
        let totalPages = 1;
        let currentFilter = ''; // Variável para armazenar o filtro de status

        // Função para buscar os dados com base no número de série
        function searchData() {
            const searchValue = document.getElementById('searchNumeroSerie').value;

            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'search_chamados.php?search=' + encodeURIComponent(searchValue) + '&page=' + currentPage + '&limit=' + itemsPerPage + '&status=' + currentFilter, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    document.getElementById('resultsTable').innerHTML = response.data;
                    totalPages = response.totalPages;
                    generatePagination();
                }
            };
            xhr.send();
        }

        // Função para filtrar as OS com base no status
        function filterOS(status) {
            currentFilter = status; // Atualiza o filtro de status
            searchData(); // Reexecuta a pesquisa com o filtro aplicado
        }

        // Função para gerar a paginação
        function generatePagination() {
            const paginationHTML = `
                <button ${currentPage === 1 ? 'disabled' : ''} onclick="changePage('previous')">Anterior</button>
                <button ${currentPage === totalPages ? 'disabled' : ''} onclick="changePage('next')">Próximo</button>
            `;
            document.getElementById('pagination').innerHTML = paginationHTML;
        }

        // Função para alterar a página
        function changePage(direction) {
            if (direction === 'previous' && currentPage > 1) {
                currentPage--;
            } else if (direction === 'next' && currentPage < totalPages) {
                currentPage++;
            }
            searchData();
        }

        // Função para preencher os dados no formulário ao dar duplo clique em uma linha da tabela
        function selectEquipment(categoria, equipamento, secretaria, setor, responsavel, numeroSerie) {
            const numeroOS = 'OS' + new Date().getTime(); // Gerar um número de OS único
            const dataAbertura = new Date().toLocaleDateString('pt-BR'); // Data atual

            // Preenche os campos do formulário com as informações do equipamento
            document.getElementById('numeroOS').value = numeroOS;
            document.getElementById('dataAbertura').value = dataAbertura;
            document.getElementById('prioridade').value = 'media'; // Valor padrão
            document.getElementById('solicitante').value = ''; // Solicitação em branco
            document.getElementById('status').value = 'aberta'; // Status como "Aberta"
            document.getElementById('descricao').value = ''; // Descrição em branco
            
            // Preencher os campos adicionais
            document.getElementById('categoria').value = categoria;
            document.getElementById('equipamento').value = equipamento;
            document.getElementById('secretaria').value = secretaria;
            document.getElementById('setor').value = setor;
            document.getElementById('responsavel').value = responsavel;
            document.getElementById('numeroSerie').value = numeroSerie;
        }

        // Função para salvar a Ordem de Serviço
        function saveOS() {
            const numeroOS = document.getElementById('numeroOS').value;
            const solicitante = document.getElementById('solicitante').value;
            const prioridade = document.getElementById('prioridade').value;
            const status = document.getElementById('status').value;
            const descricao = document.getElementById('descricao').value;
            const categoria = document.getElementById('categoria').value;
            const equipamento = document.getElementById('equipamento').value;
            const secretaria = document.getElementById('secretaria').value;
            const setor = document.getElementById('setor').value;
            const responsavel = document.getElementById('responsavel').value;
            const numeroSerie = document.getElementById('numeroSerie').value;

            // Enviar os dados via AJAX para o backend (PHP)
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'save_os.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        alert('Ordem de Serviço salva com sucesso!');
                    } else {
                        alert('Erro ao salvar a OS: ' + response.error);
                    }
                }
            };

            // Enviar os dados para o backend
            xhr.send(`numeroOS=${numeroOS}&solicitante=${solicitante}&prioridade=${prioridade}&status=${status}&descricao=${descricao}&categoria=${categoria}&equipamento=${equipamento}&secretaria=${secretaria}&setor=${setor}&responsavel=${responsavel}&numeroSerie=${numeroSerie}`);
        }

        // Adicionando o evento de duplo clique na tabela
        $(document).ready(function() {
            $('#resultsTable').on('dblclick', 'tr', function() {
                const categoria = $(this).find('td').eq(0).text();
                const equipamento = $(this).find('td').eq(1).text();
                const secretaria = $(this).find('td').eq(2).text();
                const setor = $(this).find('td').eq(3).text();
                const responsavel = $(this).find('td').eq(4).text();
                const numeroSerie = $(this).find('td').eq(5).text();

                selectEquipment(categoria, equipamento, secretaria, setor, responsavel, numeroSerie);
            });
        });
    </script>
</body>
</html>
