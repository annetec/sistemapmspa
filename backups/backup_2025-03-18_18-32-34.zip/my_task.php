<?php
session_start();

// Verificar se o usuário está logado e se tem um papel (role) e id definidos
if (!isset($_SESSION['role']) || !isset($_SESSION['id'])) {
    header("Location: login.php?error=First login");
    exit();
}

include "DB_connection.php";
include "app/Model/Task.php";
include "app/Model/User.php";

// Definir variáveis de sessão
$userId = $_SESSION['id'];
$role = $_SESSION['role'];

// Funções para o papel admin ou usuário regular
if ($role === "admin") {
    // Funções específicas para o administrador
    $todaydue_task = count_tasks_due_today($conn);
    $overdue_task = count_tasks_overdue($conn);
    $nodeadline_task = count_tasks_NoDeadline($conn);
    $num_task = count_tasks($conn);
    $num_users = count_users($conn);
    $pending = count_pending_tasks($conn);
    $in_progress = count_in_progress_tasks($conn);
    $completed = count_completed_tasks($conn);
} else {
    // Funções específicas para o usuário regular
    $num_my_task = count_my_tasks($conn, $userId);
    $overdue_task = count_my_tasks_overdue($conn, $userId);
    $nodeadline_task = count_my_tasks_NoDeadline($conn, $userId);
    $pending = count_my_pending_tasks($conn, $userId);
    $in_progress = count_my_in_progress_tasks($conn, $userId);
    $completed = count_my_completed_tasks($conn, $userId);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Interno</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Estilo do formulário e outros componentes */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 60%;
            margin: 40px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        h4 {
            text-align: center;
            color: #333;
            font-size: 26px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 16px;
            background-color: #f9f9f9;
        }
        .btn-container {
            text-align: center;
            margin-top: 30px;
        }
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            color: #fff;
            transition: 0.3s;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <input type="checkbox" id="checkbox">
    <?php include "inc/header.php"; ?>
    <div class="body">
        <?php include "inc/nav.php"; ?>
        <section class="section-1">
            <h4 class="title text-center">Novo Cadastro de Equipamento</h4>
            <div class="container">
                <form action="processa_cadastro.php" method="POST" class="shadow p-4 bg-light rounded">
                    <div class="row">
                        <div class="col form-group">
                            <label for="categoria">Categoria:</label>
                            <select id="categoria" name="categoria" class="form-control" required onchange="verificarRoteador()">
                                <option value="">Selecione...</option>
                                <option value="Computador">Computador</option>
                                <option value="Notebook">Notebook</option>
                                <option value="Impressora">Impressora</option>
                                <option value="Monitor">Monitor</option>
                                <option value="Nobreak">Nobreak</option>
                                <option value="DockStation">DockStation</option>
                                <option value="Roteador">Roteador</option>
                                <option value="Outros">Outros</option>
                            </select>
                        </div>
                        <div id="campoEquipamento" class="col form-group">
                            <label for="equipamento">Equipamento:</label>
                            <input type="text" id="equipamento" name="equipamento" class="form-control" required>
                        </div>
                    </div>

                    <script>
                        // Função para ocultar/mostrar campos com base na categoria selecionada
                        function verificarRoteador() {
                            var categoria = document.getElementById("categoria").value;
                            var camposRoteador = document.getElementById("camposRoteador");
                            var campoEquipamento = document.getElementById("campoEquipamento");
                            var campoNumeroSerie = document.getElementById("campoNumeroSerie");
                            var campoNomeComputador = document.getElementById("campoNomeComputador");
                            var campoEnderecoIP = document.getElementById("campoEnderecoIP");
                            var campoObservacao = document.getElementById("campoObservacao");

                            if (categoria === "Roteador") {
                                camposRoteador.style.display = "block";
                                campoEquipamento.style.display = "none";
                                campoNumeroSerie.style.display = "none";
                                campoNomeComputador.style.display = "none";
                                campoEnderecoIP.style.display = "none";
                                campoObservacao.style.display = "none";
                                document.getElementById("equipamento").disabled = true;
                                document.getElementById("numero_serie").disabled = true;
                                document.getElementById("nome_computador").disabled = true;
                                document.getElementById("ip").disabled = true;
                                document.getElementById("observacao").disabled = true;
                            } else {
                                camposRoteador.style.display = "none";
                                campoEquipamento.style.display = "block";
                                campoNumeroSerie.style.display = "block";
                                campoNomeComputador.style.display = "block";
                                campoEnderecoIP.style.display = "block";
                                campoObservacao.style.display = "block";
                                document.getElementById("equipamento").disabled = false;
                                document.getElementById("numero_serie").disabled = false;
                                document.getElementById("nome_computador").disabled = false;
                                document.getElementById("ip").disabled = false;
                                document.getElementById("observacao").disabled = false;
                            }
                        }
                    </script>

                    <br>
                    <div class="row">
                        <div id="campoNumeroSerie" class="col form-group">
                            <label for="numero_serie">Número de Série:</label>
                            <input type="text" id="numero_serie" name="numero_serie" class="form-control" required>
                        </div>
                        <div class="col form-group">
                            <label for="secretaria">Secretaria:</label>
                            <select id="secretaria" name="secretaria" class="form-control" required>
                                <option value="">Selecione...</option>
                                <option value="Administração">Administração</option>
                                <option value="Agricultura">Agricultura</option>
                                <option value="Assistência Social">Assistência Social</option>
                                <option value="Controladoria">Controladoria</option>
                                <option value="Cultura">Cultura</option>
                                <option value="Desenvolvimento Econômico">Desenvolvimento Econômico</option>
                                <option value="Educação">Educação</option>
                                <option value="Esporte e Lazer">Esporte e Lazer</option>
                                <option value="Fazenda">Fazenda</option>
                                <option value="Governo">Governo</option>
                                <option value="Licitações e Contratos">Licitações e Contratos</option>
                                <option value="Meio Ambiente">Meio Ambiente</option>
                                <option value="Obras">Obras</option>
                                <option value="Ordem Pública">Ordem Pública</option>
                                <option value="Planejamento e Gestão">Planejamento e Gestão</option>
                                <option value="Previspa">Previspa</option>
                                <option value="Procon">Procon</option>
                                <option value="Procuradoria Geral">Procuradoria Geral</option>
                                <option value="Saúde">Saúde</option>
                                <option value="Serviços Públicos">Serviços Públicos</option>
                                <option value="Turismo">Turismo</option>
                                <option value="Segurança">Segurança</option>
                            </select>
                        </div>

                        <div class="col form-group">
                            <label for="setor">Setor:</label>
                            <input type="text" id="setor" name="setor" class="form-control" required>
                        </div>
                    </div>

                    <div class="row">
                        <div id="campoNomeComputador" class="col form-group">
                            <label for="nome_computador">Nome do Computador:</label>
                            <input type="text" id="nome_computador" name="nome_computador" class="form-control">
                        </div>
                        <div id="campoEnderecoIP" class="col form-group">
                            <label for="ip">Endereço IP:</label>
                            <input type="text" id="ip" name="ip" class="form-control">
                        </div>
                    </div>

                    <div id="campoObservacao" class="form-group">
                        <label for="observacao">Observações:</label>
                        <textarea id="observacao" name="observacao" class="form-control" rows="4"></textarea>
                    </div>

                    <div class="btn-container">
                        <button type="submit" class="btn btn-success">Cadastrar</button>
                        <a href="my_task.php" class="btn btn-danger">Cancelar</a>
                    </div>
                </form>
            </div>
        </section>
    </div>
</body>
</html>
