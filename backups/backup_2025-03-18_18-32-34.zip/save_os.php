<?php
// Conectar ao banco de dados
$host = 'localhost'; // Endereço do banco de dados
$dbname = 'nome_do_banco'; // Nome do banco de dados
$username = 'root'; // Usuário do banco de dados
$password = ''; // Senha do banco de dados

// Conectar com PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Erro de conexão: ' . $e->getMessage()]);
    exit;
}

// Verificar se a requisição é do tipo POST e se os dados necessários estão presentes
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe os dados via POST
    $numeroOS = isset($_POST['numeroOS']) ? $_POST['numeroOS'] : '';
    $solicitante = isset($_POST['solicitante']) ? $_POST['solicitante'] : '';
    $prioridade = isset($_POST['prioridade']) ? $_POST['prioridade'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $descricao = isset($_POST['descricao']) ? $_POST['descricao'] : '';
    $categoria = isset($_POST['categoria']) ? $_POST['categoria'] : '';
    $equipamento = isset($_POST['equipamento']) ? $_POST['equipamento'] : '';
    $secretaria = isset($_POST['secretaria']) ? $_POST['secretaria'] : '';
    $setor = isset($_POST['setor']) ? $_POST['setor'] : '';
    $responsavel = isset($_POST['responsavel']) ? $_POST['responsavel'] : '';
    $numeroSerie = isset($_POST['numeroSerie']) ? $_POST['numeroSerie'] : '';

    // Inserir os dados no banco de dados
    $sql = "INSERT INTO ordens_servico (numero_os, solicitante, prioridade, status, descricao, categoria, equipamento, secretaria, setor, responsavel, numero_serie) 
            VALUES (:numeroOS, :solicitante, :prioridade, :status, :descricao, :categoria, :equipamento, :secretaria, :setor, :responsavel, :numeroSerie)";
    
    $stmt = $pdo->prepare($sql);
    
    // Bind dos parâmetros
    $stmt->bindParam(':numeroOS', $numeroOS);
    $stmt->bindParam(':solicitante', $solicitante);
    $stmt->bindParam(':prioridade', $prioridade);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':categoria', $categoria);
    $stmt->bindParam(':equipamento', $equipamento);
    $stmt->bindParam(':secretaria', $secretaria);
    $stmt->bindParam(':setor', $setor);
    $stmt->bindParam(':responsavel', $responsavel);
    $stmt->bindParam(':numeroSerie', $numeroSerie);

    // Executar a query
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Erro ao salvar a OS']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Método inválido']);
}
?>
