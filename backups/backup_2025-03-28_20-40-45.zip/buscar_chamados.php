<?php
// Incluir o arquivo de configuração do banco de dados
include('config_chamados.php');

// Número de resultados por página
$itens_por_pagina = 5;

// Verificar se o parâmetro de página foi passado na URL
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;

// Calcular o valor do offset para a consulta SQL
$offset = ($pagina - 1) * $itens_por_pagina;

// Receber o número de série para busca
if (isset($_GET['nserie'])) {
    $nserie = $_GET['nserie'];

    // Consultar os chamados com base no número de série e outras colunas, limitando a 5 resultados por vez
    $sql = "SELECT * FROM chamados WHERE 
            equipamento LIKE '%$nserie%' OR
            categoria LIKE '%$nserie%' OR
            numero_serie LIKE '%$nserie%' OR
            secretaria LIKE '%$nserie%' OR
            responsavel LIKE '%$nserie%' OR
            setor LIKE '%$nserie%' LIMIT $itens_por_pagina OFFSET $offset";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Exibe a tabela de resultados com estilos aprimorados
        echo '<table class="styled-table">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Equipamento</th>';
        echo '<th>Categoria</th>';
        echo '<th>Número de Série</th>';
        echo '<th>Secretaria</th>';
        echo '<th>Responsável</th>';
        echo '<th>Setor</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        // Se houver resultados, vamos exibi-los em linhas da tabela
        while ($row = $result->fetch_assoc()) {
            echo '<tr class="clickable-row" data-numero-serie="' . htmlspecialchars($row['numero_serie']) . '">';
            echo '<td>' . htmlspecialchars($row['equipamento']) . '</td>';
            echo '<td>' . htmlspecialchars($row['categoria']) . '</td>';
            echo '<td>' . htmlspecialchars($row['numero_serie']) . '</td>';
            echo '<td>' . htmlspecialchars($row['secretaria']) . '</td>';
            echo '<td>' . htmlspecialchars($row['responsavel']) . '</td>';
            echo '<td>' . htmlspecialchars($row['setor']) . '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';

        // Contar o total de resultados para a navegação
        $count_sql = "SELECT COUNT(*) as total FROM chamados WHERE 
                      numero_serie LIKE '%$nserie%' OR
                      secretaria LIKE '%$nserie%' OR
                      responsavel LIKE '%$nserie%' OR
                      setor LIKE '%$nserie%'";
        $count_result = $conn->query($count_sql);
        $count_row = $count_result->fetch_assoc();
        $total_registros = $count_row['total'];
        $total_paginas = ceil($total_registros / $itens_por_pagina);

        // Adicionar navegação de página
        echo '<div class="pagination">';
        if ($pagina > 1) {
            echo '<a href="?nserie=' . urlencode($nserie) . '&pagina=' . ($pagina - 1) . '">Anterior</a>';
        }

        if ($pagina < $total_paginas) {
            echo '<a href="?nserie=' . urlencode($nserie) . '&pagina=' . ($pagina + 1) . '">Próximo</a>';
        }
        echo '</div>';

    } else {
        echo '<p>Nenhum chamado encontrado.</p>';
    }
} else {
    echo '<p>Por favor, insira um número de série para buscar.</p>';
}
?>

<!-- Label para mostrar o número de série selecionado -->
<div>
    <label id="numero-serie-selecionado">Número de Série Selecionado: Nenhum</label>
</div>

<style>
    /* Estilos aprimorados para a tabela */
    .styled-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    .styled-table thead {
        background-color: #007bff;
        color: white;
    }

    .styled-table th, .styled-table td {
        padding: 12px;
        text-align: left;
    }

    .styled-table th {
        font-size: 16px;
        font-weight: bold;
    }

    .styled-table tbody tr {
        border-bottom: 1px solid #ddd;
    }

    .styled-table tbody tr:hover {
        background-color: #f2f2f2;
        cursor: pointer;
    }

    .styled-table td {
        font-size: 14px;
        color: #555;
    }

    .styled-table tbody tr:nth-of-type(even) {
        background-color: #f9f9f9;
    }

    .styled-table tbody tr:last-of-type {
        border-bottom: 2px solid #007bff;
    }

    /* Estilos para a navegação de página */
    .pagination {
        text-align: center;
        margin-top: 20px;
    }

    .pagination a {
        margin: 0 10px;
        padding: 8px 15px;
        text-decoration: none;
        background-color: #007bff;
        color: white;
        border-radius: 5px;
    }

    .pagination a:hover {
        background-color: #0056b3;
    }

    /* Estilo para a label do número de série */
    #numero-serie-selecionado {
        margin-top: 20px;
        font-size: 16px;
        font-weight: bold;
    }
</style>

<script>
    // Aguardar o carregamento completo do DOM
    document.addEventListener("DOMContentLoaded", function() {
        // Selecionar todas as linhas com a classe 'clickable-row'
        const rows = document.querySelectorAll('.clickable-row');
        
        // Para cada linha, adicionar um evento de clique
        rows.forEach(row => {
            row.addEventListener('click', function() {
                // Captura o número de série a partir do atributo 'data-numero-serie'
                const numeroSerie = this.getAttribute('data-numero-serie');
                console.log('Número de Série capturado:', numeroSerie);  // Verificar no console

                // Se o número de série existir, atualiza o conteúdo da label
                if (numeroSerie) {
                    const label = document.getElementById('numero-serie-selecionado');
                    label.textContent = 'Número de Série Selecionado: ' + numeroSerie;
                }
            });
        });
    });
</script>
